#include <cstdio>
#include <cmath>
#include <cfloat>

int main()
{
    const size_t MAX_ORDER = 42;

    size_t order;
    double matrix[MAX_ORDER][MAX_ORDER];
    double rightSide[MAX_ORDER];


    printf("Enter the system order: ");
    scanf("%u", &order);

    puts("Enter system matrix:");
    for (size_t i = 0; i < order; ++i)
    {
        for (size_t j = 0; j < order; ++j)
        {
            scanf("%lf", &matrix[i][j]);
        }
    }

    puts("Enter right side vector:");
    for (size_t i = 0; i < order; ++i)
    {
        scanf("%lf", &rightSide[i]);
    }


    for (size_t i = 0; i < order; ++i)
    {
        if (fabs(matrix[i][i]) < DBL_EPSILON)
        {
            for (size_t j = i + 1; j < order; ++j)
            {
                if (fabs(matrix[j][i]) >= DBL_EPSILON)
                {
                    for (size_t m = 0; m < order; ++m)
                    {
                        double z = matrix[i][m];
                        matrix[i][m] = matrix[j][m];
                        matrix[j][m] = z;
                    }
                    double z = rightSide[i];
                    rightSide[i] = rightSide[j];
                    rightSide[j] = z;
                    break;
                }
            }
        }
        for (size_t j = i + 1; j < order; ++j)
        {
            double k = matrix[j][i] / matrix[i][i];
            for (size_t m = 0; m < order; ++m)
            {
                matrix[j][m] -= matrix[i][m] * k;
            }
            rightSide[j] -= rightSide[i] * k;
        }
    }


    double x[MAX_ORDER];
    x[order - 1] = rightSide[order - 1] / matrix[order - 1][order - 1];
    for (int i = order - 2; i >= 0; --i)
    {
        double sum = 0;	// Отдельная переменная для суммы (более логично).
        for (int j = order - 1; j > i; --j)
        {
            sum += matrix[i][j] * x[j];
        }
        x[i] = (rightSide[i] - sum) / matrix[i][i];
    }


    puts("Solution is: ");
    for (size_t i = 0; i < order; ++i)
    {
        printf("\t%g\n", x[i]);	// Новый формат вывода (см. cppreference.com).
    }

    return 0;
}
