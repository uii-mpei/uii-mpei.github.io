#include <cstdio>
#include <cstring>

// Интерфейс "Нечто печатаемое".
class Printable
{
public:
	// Чисто виртуальный метод, печатающий объект.
	// Принципиально не может быть реализован в Printable,
	// но должен быть реализован в конкретных наследниках.
    virtual void print() = 0;

    // Чисто виртуальный деструктор.
    virtual ~Printable() = 0;
};

// Деструктор всегда обязан иметь реализацию,
// даже если он чисто виртуальный.
Printable::~Printable()
{
}


// Класс, представляющий банковский счет.
class Account : public Printable
{
private:
	// Эта функция содержит повторяющийся код копирования
	// строки имени владельца счета.
	void setOwnerName(const char *theOwnerName)
	{
		size_t length = strlen(theOwnerName);
        this->ownerName = new char[length + 1];
        strcpy(ownerName, theOwnerName);
	}
protected:
    char *ownerName;	// Имя владельца.
    long number;		// Номер счета.
    double balance;		// Сумма средств на счете.
public:
	// Такие простые функции доступа к данным часто реализуются
	// прямо на месте (inline), в заголовочном файле.
    char* getOwnerName() { return ownerName; }
    long getNumber() { return number; }
    double getBalance() { return balance; }

    bool deposit(double amount)
    {
        if (amount >= 0)
        {
            balance += amount;
            return true;
        }
        return false;
    }

    virtual bool withdraw(double amount)
    {
        if (amount > 0 && amount <= balance)
        {
            balance -= amount;
            return true;
        }
        return false;
    }

    Account(char *theOwnerName, long theNumber)
    {
        number = theNumber;
        balance = 0.0;
        setOwnerName(theOwnerName);
    }

    Account(const Account& source)
    {
        number = source.number;
        balance = source.balance;
        setOwnerName(source.ownerName);
    }

	// Перегруженный оператор присваивания.
    Account& operator=(const Account& source)
    {
        if (this != &source)
        {
            number = source.number;
            balance = source.balance;
            delete [] ownerName;
            setOwnerName(source.ownerName);
        }
        return *this;
    }

    virtual ~Account()
    {
        puts("Account dtor call.");
        delete [] ownerName;
    }

	// Реализация виртуального метода print().
    virtual void print()
    {
        printf(
            "Account owner: %s\nNumber: %ld\nBalance: %g\n",
            getOwnerName(),
            getNumber(),
            getBalance());
    }
};

Account printAccount(Account &account)
{
    account.print();
    account.withdraw(10);
    return account;
}

class CreditAccount : public Account
{
public:
    CreditAccount(char *theOwnerName, long theNumber)
        : Account(theOwnerName, theNumber)
    {
    }

    virtual bool withdraw(double amount) override
    {
        balance -= amount;
        return true;
    }

	// Перекрытие виртуального деструктора для демонстрации,
	// что именно он автоматически вызывается delete.
    virtual ~CreditAccount()
    {
        puts("CreditAccount dtor call.");
    }

    // Новая реализация виртуального метода print().
    virtual void print()
    {
        printf(
            "Credit account owner: %s\nNumber: %ld\nBalance: %g\n",
            getOwnerName(),
            getNumber(),
            getBalance());
    }
};

int main()
{
    long number;
    double amount;
    char ownerName[255];
    printf("Enter account owner's name: ");
    scanf("%s", ownerName);
    printf("Enter account number: ");
    scanf("%ld", &number);

    Account* account
        = new CreditAccount(ownerName, number);

	printf("Enter initial account balance: ");
    scanf("%lf", &amount);
    account->deposit(amount);

    //account = printAccount(account);
    printAccount(*account);

    delete account;

    return 0;
}
