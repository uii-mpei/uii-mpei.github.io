#ifndef FIXEDSIZEARRAY_H_INCLUDED
#define FIXEDSIZEARRAY_H_INCLUDED

#include "ICollection.h"

// Простейший класс массива, размер которого задаётся
// при создании и в дальнейшем не изменяется.
class FixedSizeArray: public ICollection
{
private:
	Type* elements; // Указатель на область памяти, где хранятся элементы массива.
	size_t size; 	// Размер массива.

public:
	FixedSizeArray(size_t arrSize);
	FixedSizeArray(const FixedSizeArray& source);

public:
	virtual Type& at (unsigned int index);
	virtual Type& operator[] (unsigned int index);
	virtual void insert(unsigned int index, Type element);
	virtual void removeAt(unsigned int index);
	virtual Type& getFirst();
	virtual Type& getLast();
	virtual size_t getSize() { return size; }

public:
	FixedSizeArray& operator=(const FixedSizeArray& source);

public:
	virtual ~FixedSizeArray();
};

#endif // FIXEDSIZEARRAY_H_INCLUDED
