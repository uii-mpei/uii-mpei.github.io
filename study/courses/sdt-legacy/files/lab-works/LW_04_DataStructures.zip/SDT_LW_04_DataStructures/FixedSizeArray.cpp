#include "FixedSizeArray.h"
#include <cstring>

//Описание методов класса fixedArray
FixedSizeArray::FixedSizeArray(size_t arrSize)
{
	size = arrSize;
	elements = new Type[size];
}

FixedSizeArray::FixedSizeArray(const FixedSizeArray& source) //Конструктор копирования
{
	size = source.size;
	elements = new Type[size];

	// Функция memcpy() копирует данные объёмом size байт
	// из одной области памяти в другую (области не должны пересекаться).
	memcpy(elements, source.elements, size * sizeof(Type));
}


FixedSizeArray& FixedSizeArray::operator= (const FixedSizeArray& sourse)
{
	if (this == &sourse)
		return *this;

	// Такая реализация наиболее корректна вот почему: если не удастся
	// выделить память под новый массив, старый останется неприкосновенен,
	// и состояние старого объекта не будет испорчено.
	Type* newElements = new Type[size];
	delete [] elements;
	elements = newElements;

	memcpy(newElements, sourse.elements, size * sizeof(Type));
	size = sourse.size;

	return *this;
}

Type& FixedSizeArray::at(unsigned int index)
{
	return elements[index];
}

Type& FixedSizeArray::operator[](unsigned int index)
{
	return at(index);
}

Type& FixedSizeArray::getFirst()
{
	return *elements;
}

Type& FixedSizeArray::getLast()
{
	return elements[size - 1];
}

void FixedSizeArray::removeAt(unsigned int index)
{
	// Не реализован, поскольку не нужен.
}

void FixedSizeArray::insert(unsigned int index, Type element)
{
	// Не реализован, поскольку не нужен.
}

FixedSizeArray::~FixedSizeArray()
{
	delete [] elements;
}
