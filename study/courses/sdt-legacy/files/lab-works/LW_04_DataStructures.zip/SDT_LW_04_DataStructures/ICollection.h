#ifndef ICOLLECTION_H_INCLUDED
#define ICOLLECTION_H_INCLUDED

// В этом заголовочном файле определен тип size_t (большое беззнаковое целое).
#include <cstddef>

// Определение псевдонима Type для типа элементов, хранимых коллекциями.
// В данном случае используется int, то есть, все Type заменяются на int.
typedef int Type;

// Интерфейс коллециии элементов типа Type.
// Интерфейсом в С++ называют абстрактный класс, у которого все методы
// (кроме, возможно, деструктора) чисто виртуальные.
// Более общо, интерфейс -- это набор средств взаимодействия с чем-либо.
class  ICollection
{
public:
	// Оба метода позволяют получить доступ к элементам по индексу.
	virtual Type& at(unsigned int index) = 0;
	virtual Type& operator[] (unsigned int index) =  0;

	// Вставка элемента element на позицию index.
	virtual void insert(unsigned int index, Type element) = 0;

	// Удаление элемента на позиции index.
	virtual void removeAt(unsigned int index) = 0;

	// Получение начального (первого) элемента: c.first() == c[0].
	virtual Type& getFirst() = 0;

	// Получение последнего элемента: c.last() == c[c.getSize() - 1].
	virtual Type& getLast() = 0;

	// Получение размера колелкции (количества элементов).
	virtual size_t getSize() = 0;

	// Деструктор объявляется чисто виртуальным, так как у интерфейса
	// заведомо будут классы-наследники, реализующие его.
	virtual ~ICollection() { }
};

#endif // ICOLLECTION_H_INCLUDED
