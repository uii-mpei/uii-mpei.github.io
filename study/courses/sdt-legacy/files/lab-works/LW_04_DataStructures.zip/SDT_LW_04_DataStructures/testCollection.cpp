#include <cassert>
#include "ICollection.h"

void testCollection(ICollection& collection)
{
	// Ожидается пустая коллекция для тестирования.
	assert(collection.getSize() == 0);

	Type element = Type(0);
	collection.insert(0, element);
	//	а) размер коллекции увеличивается на 1.
	assert(collection.getSize() == 1);
	//	б) Последний и последний элементы совпадают и равны вставленному.
	assert(collection.getLast() == element);
	assert(collection.getFirst() == element);
	//	в) По индексу 0 доступен вставленный элемент.
	assert(collection.at(0) == element);
	assert(collection[0] == element);

	// После удаления единственного элемента коллекция пустеет.
	collection.removeAt(0);
	assert(collection.getSize() == 0);

	const size_t count = 10;
	for (size_t i = 0; i < count; ++i)
	{
		// После вставки единственного элемента должно выполняться:
		Type anElement = Type(i);
		collection.insert(i, anElement);
		//	а) размер коллекции увеличивается на 1.
		assert(collection.getSize() == i + 1);
		//	б) Последний элемент -- добавленный.
		assert(collection.getLast() == anElement);
		//	в) По индексу 0 доступен вставленный элемент.
		assert(collection.at(i) == anElement);
		assert(collection[i] == anElement);
	}
	assert(collection.getSize() == count);

	for (size_t i = 0; i < count; ++i)
	{
		collection.removeAt(i % collection.getSize());
		assert(collection.getSize() == count - i - 1);
	}
	assert(collection.getSize() == 0);
}
