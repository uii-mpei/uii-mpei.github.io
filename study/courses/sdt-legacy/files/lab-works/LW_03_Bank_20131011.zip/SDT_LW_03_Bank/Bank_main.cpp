#include <cstdio>
#include <cstring>

class Account
{
private:
    char *ownerName;
    long number;
    double balance;
public:
    char* getOwnerName() { return ownerName; }
    long getNumber() { return number; }
    double getBalance() { return balance; }

    bool deposit(double amount)
    {
        if (amount >= 0)
        {
            balance += amount;
            return true;
        }
        return false;
    }

    bool withdraw(double amount)
    {
        if (amount > 0 && amount <= balance)
        {
            balance -= amount;
            return true;
        }
        return false;
    }

    Account(char *theOwnerName, long theNumber)
    {
        number = theNumber;
        balance = 0.0;
        size_t length = strlen(theOwnerName);
        this->ownerName = new char[length + 1];
        strcpy(ownerName, theOwnerName);
    }

    Account(const Account& source)
    {
        number = source.number;
        balance = source.balance;
        size_t length = strlen(source.ownerName);
        this->ownerName = new char[length + 1];
        strcpy(ownerName, source.ownerName);
    }

    ~Account()
    {
        delete [] ownerName;
    }
};

Account printAccount(Account& account)
{
    printf(
        "Owner: %s\nNumber: %ld\nBalance: %g\n",
        account.getOwnerName(),
        account.getNumber(),
        account.getBalance());
    account.withdraw(10);
    return account;
}

int main()
{
    long number;
    double amount;
    char ownerName[255];
    scanf("%s", ownerName);
    scanf("%ld", &number);

    Account account(ownerName, number);

    scanf("%lf", &amount);
    account.deposit(amount);

    account = printAccount(account);
    printAccount(account);

    return 0;
}
