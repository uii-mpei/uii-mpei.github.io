#include "DebitAccount.h"
#include <cstring>
#include <cstdio>

DebitAccount::DebitAccount(const char *theOwnerName, int theNumber)
{
	setOwnerName(theOwnerName);
	number = theNumber;
	balance = 0.0;
	frozen = false;
}

DebitAccount::~DebitAccount()
{
	delete [] ownerName;
}

DebitAccount::DebitAccount(const DebitAccount& other)
{
	number = other.number;
	balance = other.balance;
	frozen = other.frozen;
	setOwnerName(other.ownerName);
}

DebitAccount& DebitAccount::operator=(const DebitAccount& rhs)
{
	if (this != &rhs)
	{
		this->number = rhs.number;
		this->balance = rhs.balance;
		this->frozen = rhs.frozen;
		delete [] ownerName;
		setOwnerName(rhs.ownerName);
	}
	return *this;
}

void DebitAccount::setOwnerName(const char *name)
{
	size_t length = strlen(name);
	ownerName = new char[length + 1];
	strcpy(ownerName, name);
}

void DebitAccount::freeze()
{
	frozen = true;
}

void DebitAccount::unfreeze()
{
	frozen = false;
}

bool DebitAccount::deposit(double amount)
{
	if (!frozen && amount > 0)
	{
		balance += amount;
		return true;
	}
	return false;
}

bool DebitAccount::withdraw(double amount)
{
	if (!frozen && amount > 0 && amount <= balance)
	{
		balance -= amount;
		return true;
	}
	return false;
}

void DebitAccount::close()
{
	delete this;
}

void DebitAccount::print()
{
    printf("Account # %d details:\n", number);
	printf("\t%7s: %s\n\t%7s: %.2f\n\t%7s: %s\n",
		"Owner", ownerName,
		"Balance", balance,
		"Frozen", frozen ? "yes" : "no");
}