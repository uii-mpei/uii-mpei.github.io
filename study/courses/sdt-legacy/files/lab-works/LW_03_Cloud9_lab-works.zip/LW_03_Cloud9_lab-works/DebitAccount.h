#ifndef DEBITACCOUNT_H
#define DEBITACCOUNT_H

class DebitAccount
{
public:
	DebitAccount(const char *theOwnerName, int theNumber);
	virtual ~DebitAccount();
	DebitAccount(const DebitAccount& other);
	DebitAccount& operator=(const DebitAccount& other);
public:
	const char* getOwnerName() { return ownerName; }
	const int getNumber() { return number; }
	const double getBalance() { return balance; }
	const bool isFrozen() { return frozen; }
public:
	bool deposit(double amount);
	virtual bool withdraw(double amount);
	void freeze();
	void unfreeze();
	void close();
public:
    virtual void print();
private:
	void setOwnerName(const char *name);
protected:
	char *ownerName;
	int number;
	double balance;
	bool frozen;
};

#endif // DEBITACCOUNT_H
