#include "CreditAccount.h"
#include <cstdio>

bool CreditAccount::withdraw(double amount)
{
    if (!frozen && amount <= limit + balance)
    {
        
        balance -= amount;
        return true;
    }
    return false;
}

CreditAccount::CreditAccount(const char *theOwnerName, int number, double local_limit)
    : DebitAccount(theOwnerName, number)
{
    limit = local_limit;
}

void CreditAccount::print()
{
    printf("Account # %d details:\n", number);
	printf("\t%7s: %s\n\t%7s: %.2f\n\t%7s: %.2f\n\t%7s: %s\n",
		"Owner", ownerName,
		"Balance", balance,
		"Limit", limit,
		"Frozen", frozen ? "yes" : "no");
}