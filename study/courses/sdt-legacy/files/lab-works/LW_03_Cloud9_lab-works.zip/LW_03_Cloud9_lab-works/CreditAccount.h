#ifndef CREDITACCOUNT_H
#define CREDITACCOUNT_H

#include "DebitAccount.h"

class CreditAccount : public DebitAccount
{
public:
    CreditAccount(const char *theOwnerName, int number, double local_limit);
    
public:
    virtual bool withdraw(double amount);
    virtual ~CreditAccount() { }
    virtual void print();
public:
    double limit;
};


#endif