/*	Авторское решение общего задания № 1 к ЛР № 3.
 *	Используются только те возможности, о которых студенты хорошо осведомлены.
 *	Автор: 	Козлюк Дмитрий
 *	Дата:	22.10.2013
 */

#include <cstdio>
#include <cctype>

#include "DebitAccount.h"
#include "CreditAccount.h"

const int INVALID_INDEX = -1;

int findAccountIndexByNumber(
	DebitAccount* accounts[], const size_t count, const int number)
{
	for (size_t i = 0; i < count; ++i)
	{
		if (accounts[i]->getNumber() == number)
			return i;
	}
	return INVALID_INDEX;
}

int inputAccountNumber()
{
	int number;
	printf("Enter the number of the desired account: ");
	scanf("%d", &number);
	return number;
}


void showHelp()
{
	puts("Available actions:");
	puts("\tO)pen an account");
	puts("\tP)rint account information");
	puts("\tS)how account registry");
	puts("\tD)deposit money");
	puts("\tW)ithdraw money");
	puts("\tF)reeze an account");
	puts("\tU)nfreeze an account");
	puts("\tC)lose an account");
	puts("\tH)elp (displays this message)");
	puts("\tQ)uit");
	puts("Enter the letter corresponding to your desired action.");
}

int main()
{
    DebitAccount a("A", 1);
    DebitAccount b("B", 2);
    a = b;

	const size_t MAX_ACCOUNTS = 10;

	DebitAccount *accounts[MAX_ACCOUNTS];
	size_t accountQuantity = 0;

	const size_t MAX_OWNER_NAME_LENGTH = 255;
	int index;
	int number;
	char ownerName[MAX_OWNER_NAME_LENGTH + 1];
	double amount;

	puts("WELCOME to the interactive BANKING PROGRAM!");
	showHelp();

	bool running = true;
    do
	{
		printf("> ");

		char choice;
		do
			choice = tolower(getchar());
		while (isspace(choice));

		switch (choice)
		{
		case 'o':
			if (accountQuantity >= MAX_ACCOUNTS)
			{
				puts("Error: maximum number of accounts reached.");
				break;
			}
			printf("Enter account number: ");
			scanf("%d", &number);
			printf("Enter owner's name: ");
			while (getchar() != '\n');
			gets(ownerName);
			printf("Select account type, (D)eposit or (C)redit: ");
			scanf("%c", &choice);
			if (choice == 'd')
			    accounts[accountQuantity] =
			        new DebitAccount(ownerName, number);
			else if (choice == 'c')
			    accounts[accountQuantity] =
			        new CreditAccount(ownerName, number, 1000.0);
			accountQuantity++;
			puts("Account opened successfully.");
			break;


		case 'p':
			number = inputAccountNumber();
			index = findAccountIndexByNumber(accounts, accountQuantity, number);
			if (index != INVALID_INDEX)
				accounts[index]->print();
			else
				puts("Error: account not found.");
			break;

		case 'd':
			number = inputAccountNumber();
			index = findAccountIndexByNumber(accounts, accountQuantity, number);
			if (index != INVALID_INDEX)
			{
				printf("Enter the amount of money to deposit: ");
				scanf("%lf", &amount);
				if (accounts[index]->deposit(amount))
					puts("Transaction commited.");
				else
					puts("Error: transaction cancelled.");
			}
			else
				puts("Error: account not found.");
			break;


		case 'w':
			number = inputAccountNumber();
			index = findAccountIndexByNumber(accounts, accountQuantity, number);
			if (index != INVALID_INDEX)
			{
				printf("Enter the amount of money to withdraw: ");
				scanf("%lf", &amount);
				if (accounts[index]->withdraw(amount))
					puts("Transaction commited.");
				else
					puts("Error: transaction cancelled.");
			}
			else
				puts("Error: account not found.");
			break;


		case 'f':
			number = inputAccountNumber();
			index = findAccountIndexByNumber(accounts, accountQuantity, number);
			if (index != INVALID_INDEX)
			{
				accounts[index]->freeze();
				puts("Account is now frozen, thus unavailable for transfers.");
			}
			else
				puts("Error: account not found.");
			break;


		case 'u':
			number = inputAccountNumber();
			index = findAccountIndexByNumber(accounts, accountQuantity, number);
			if (index != INVALID_INDEX)
			{
				accounts[index]->unfreeze();
				puts("Account is now unfrozen, thus available for transfers.");
			}
			else
				puts("Error: account not found.");
			break;


		case 's':
			if (accountQuantity)
			{
				puts("Account registry:");
				for (size_t i = 0; i < accountQuantity; ++i)
					accounts[i]->print();
			}
			else
				puts("No accounts registered in the system.");
			break;


		case 'c':
			number = inputAccountNumber();
			index = findAccountIndexByNumber(accounts, accountQuantity, number);
			if (index != INVALID_INDEX)
			{
				accounts[index]->close();
				accountQuantity--;
				for (size_t i = index; i < accountQuantity; ++i)
					accounts[i] = accounts[i + 1];
				puts("Account closed successfully.");
			}
			else
				puts("Error: account not found.");
			break;


		case 'h':
			showHelp();
			break;


		case 'q':
			running = false;
			break;


		default:
			puts("Error: unrecognized command. Type 'h' to display help.");
			break;
		}

		puts("");
	}
	while (running);

	for (size_t i = 0; i < accountQuantity; ++i)
		delete accounts[i];

    return 0;
}
