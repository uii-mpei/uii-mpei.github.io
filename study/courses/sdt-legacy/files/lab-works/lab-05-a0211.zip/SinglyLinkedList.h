#ifndef SINGLYLINKEDLIST_H
#define SINGLYLINKEDLIST_H

#include <cassert>      // Макрос assert() для обработки ошибок.
#include <algorithm>    // Функция std::swap().
#include <iostream>     // Вывод объекта-списка в поток.
#include <stdexcept>    // Стандартные классы исключений.

// Предварительное объявление класса односвязного списка
// (по аналогии с объявлением прототипа функции).
template<typename Type> class SinglyLinkedList;

// Объявление прототипа специализации шаблонной функции std::swap<T>()
// для объектов класса односвязного списка.
namespace std 
{
    template<typename Type> 
    void swap(SinglyLinkedList<Type>& a, SinglyLinkedList<Type>& b);
}

// Объявление перегрузки оператора вывода объекта класса односвязного списка
// в поток. Обратите внимание, что оператор не шаблонный сам по себе,
// но становится шаблонным, поскольку классу списка нужен тип-параметр.
template<typename Type>
std::ostream& operator<<(std::ostream& stream, const SinglyLinkedList<Type>& list);

// Шаблонный класс односвязного списка.
template<typename Type>
class SinglyLinkedList
{
    struct Node 
    {
        Type data;
        Node* next;  
    };
public:
    SinglyLinkedList()
        : first(nullptr), last(nullptr), size(0)
    {
    }
    
    SinglyLinkedList(const SinglyLinkedList& source)
        : SinglyLinkedList()
    {
        Node* current = source.first;
        while (current)
        {
            append(current->data);
            current = current->next;
        }
    }
    
    // Конструктор перемещения:
    SinglyLinkedList(SinglyLinkedList&& source)
        : SinglyLinkedList() // 1) Новый объект инициализируется пустым.
    {
        swap(*this, source); // 2) Данные новый объект получает данные старого,
                             //    поля старого объекта обнуляются.
    }
    
    virtual ~SinglyLinkedList()
    {
        Node* current = first;
        while (current)
        {
            Node* obsolete = current;
            current = current->next;
            delete obsolete;
        }
    }
    
public:
    // Реализация присваивания идиомой copy & swap:
    const SinglyLinkedList& operator=(
        SinglyLinkedList other)  // 1) Создается копия объекта-источника.
    {                            //
        std::swap(*this, other); // 2) Данные копии источника заменяются на данные
                                 //    текущего объекта, более не нужные.
        return *this;            // 3) Текущий объект содержит данные копии источника,
                                 //    то есть присваивание прошло успешно.
    }                            // 4) Объект other разрушается, освобождая
                                 //    старые данные текущего объекта.
    
public:
    //                    |
    // 1) Заметьте скобки V -- это означает, что друг -- специализация шаблона.
    friend void std::swap <> (SinglyLinkedList<Type>& a, SinglyLinkedList<Type>& b);
    //                             |
    // 2) Без следующего пробела   V  компилятору не разобрать, где <<, а где <. 
    friend std::ostream& operator<< <>(std::ostream& stream, const SinglyLinkedList<Type>& list);
    
public:
    // Добавляет элемент в конец списка.
    void append(const Type& data)
    {
        Node* inserted = new Node();
        inserted->data = data;
        inserted->next = nullptr;
        if (size)
        {
            last->next = inserted;
            last = inserted;
        }
        else
        {
            first = last = inserted;
        }
        size++;
    }
    
    // Добавляет элемент в начало списка.
    void prepend(const Type& data)
    {
        Node* inserted = new Node();
        inserted->data = data;
        inserted->next = first;
        first = inserted;
        if (!size)
            last = inserted;
        size++;
    }
    
    // Вставляет элемент на заданную позицию.
    void insertAt(const Type& data, const size_t index);
    
    void removeAt(const size_t index)
    {
        if (!size)
        {
            // FIXME: Это недопустимая операция, нужно исключение.
            return;
        }
        
        if (index == 0)
        {
            Node* obsolete = first;
            first = first->next;
            delete obsolete;
        }
        else
        {
            Node* previous = getNodeAt(index - 1);
            if (previous) {

                throw std::out_of_range("Index out of range dimension");
            }
            
            
            Node* obsolete = previous->next;
            previous->next = obsolete->next;
            delete obsolete;
        }
        size--;
        if (!size)
            last = nullptr;
    }
    
    // Возвращает текущий размер списка (количество элементов).
    size_t getSize() const { return size; }

private:
    // Возвращает указатель на узел в заданной позиции.
    Node* getNodeAt(const size_t index) const
    {
        Node* current = first;
        for (size_t i = 0; current && i < index; ++i) {
            current = current->next;
        }
        return current;
    }

public:
    // Возвращает элемент на заданной позиции.
    Type getElement(const size_t index) const
    {
        Node* node = getNodeAt(index);
        if(!node)
            throw std::out_of_range("Index is not defined");
       
        return node->data;
    }
    
private:
    Node* first;
    Node* last;
    size_t size;


public:
    class Iterator
    {
    private:
        typename SinglyLinkedList<Type>::Node* node;
        friend class SinglyLinkedList<Type>;
        
    public:
        Type operator*()
        {
            return node->data;
        }
        
        Iterator& operator++()
        {
            node = node->next;
            return *this;
        }
        
        bool operator!=(const Iterator& other)
        {
            return this->node != other.node;
        }
    };
    
public:
    Iterator begin() const
    {
        Iterator iterator;
        iterator.node = first;
        return iterator;
    }
    
    Iterator end() const
    {
        Iterator iterator;
        iterator.node = nullptr;
        return iterator;
    }
};


template<typename Type>
void SinglyLinkedList<Type>::insertAt(const Type& data, const size_t index)
{
    if (!index)
        prepend(data);
    else if (index + 1 == size)
        append(data);
    else
    {
        typename SinglyLinkedList<Type>::Node* previous = getNodeAt(index - 1);
        
        if (!previous)
            throw std::out_of_range("Index out of the bounds of a linked list!");
        
        typename SinglyLinkedList<Type>::Node* inserted = new Node();
        inserted->data = data;
        inserted->next = previous->next;
        previous->next = inserted;
        size++;
    }
}


template<typename Type> 
void std::swap(SinglyLinkedList<Type>& a, SinglyLinkedList<Type>& b)
{
    std::swap(a.first, b.first);
    std::swap(a.last,  b.last);
    std::swap(a.size,  b.size);
}


template<typename Type>
std::ostream& operator<<(std::ostream& stream, const SinglyLinkedList<Type>& list)
{
    stream << "[";
    typename SinglyLinkedList<Type>::Node* current = list.first;
    for (size_t i = 0; i < list.size; ++i)
    {
        stream << current->data;
        if (i != list.size - 1)
            stream << ", ";
        current = current->next;
    }
    stream << "]";
    return stream;
}

#endif