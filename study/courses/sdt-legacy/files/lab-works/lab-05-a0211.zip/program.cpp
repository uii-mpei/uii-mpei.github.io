#include <iostream>
#include "SinglyLinkedList.h"

int main()
{
    SinglyLinkedList<double> list;
    
    for (size_t i = 0; i < 10; ++i)
        list.append(i*i);
    std::cout << list << std::endl;
    
    SinglyLinkedList<double>::Iterator iterator = list.begin();
    auto last = list.end();
    while (iterator != last)
    {
        std::cout << *iterator << std::endl;
        ++iterator;
    }
    
    return 0;
    /*
    for (size_t i = 1; i < 10; ++i)
        list.prepend(i*i);
    std::cout << list << std::endl;
    
    for (size_t i = 1; i < 10; ++i)
        list.insertAt(0, 10);
    std::cout << list << std::endl;
    
    for (size_t i = 1; i < 10; ++i) {
        try {
            list.removeAt(10);
        } catch (std::out_of_range ex) {
            std::cerr << ex.what() << std::endl; 
        }
    }
    
    std::cout << list << std::endl;
    
    try {
        list.getElement(100500);
    } catch (std::out_of_range aa) {
        std::cerr << aa.what() << std::endl;
    }
    return 0;*/
}