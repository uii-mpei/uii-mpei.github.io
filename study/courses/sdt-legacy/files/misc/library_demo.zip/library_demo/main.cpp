#include <iostream>
#include <libxml/xmlversion.h>

using namespace std;

int main() {
    xmlCheckVersion(LIBXML_VERSION);
    return 0;
}
